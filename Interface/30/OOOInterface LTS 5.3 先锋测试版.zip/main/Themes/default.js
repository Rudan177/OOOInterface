var DEFAULT_THEME = {
    "info": {
        "name": "默认主题",
        "designer": "RUDAN",
        "version": "0.1"
    },
    "details": {
        "logo": {
            "name": "默认图标",
            "location": "../images/dll.png",
            "specialStyle": {
                "dark": "../images/dln.png",
                "online": "https://rudan177.github.io/OOOInterface/images/dll.png",
                "onlineDark": "https://rudan177.github.io/OOOInterface/images/dln.png",
                "width": "120px",
                "height": "120px"
            }
        },
        "font": {
            "name": "Sans Flex",
            "location": "../fonts/GoogleSansFlex.ttf",
            "specialStyle": {
                "font-weight": "400",
                "font-size": "1em"
            }
        },
        "wallpaper": {
            "name": "默认壁纸",
            "location": "../images/back.png",
            "specialStyle": {
                "online": "https://rudan177.github.io/OOOInterface/images/back.png",
                "wallpaperFill": true
            }
        },
        "color": {
            "name": "林绿色",
            "specialStyle": {
                "colorGroup": "cjs",
                "colorScheme": "green"
            }
        },
        "more": false
    }
}
